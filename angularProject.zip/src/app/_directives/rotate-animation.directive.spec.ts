import { RotateAnimationDirective } from './rotate-animation.directive';

describe('RotateAnimationDirective', () => {
  it('should create an instance', () => {
    const directive = new RotateAnimationDirective();
    expect(directive).toBeTruthy();
  });
});
