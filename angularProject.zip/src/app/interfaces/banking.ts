export interface BankingDetails{
  updateBy: string,
  updatedOn: string
}
