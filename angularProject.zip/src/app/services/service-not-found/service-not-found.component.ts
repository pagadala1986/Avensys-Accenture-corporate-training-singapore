import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-not-found',
  templateUrl: './service-not-found.component.html',
  styleUrls: ['./service-not-found.component.css']
})
export class ServiceNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
