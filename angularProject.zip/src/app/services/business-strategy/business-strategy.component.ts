import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-strategy',
  templateUrl: './business-strategy.component.html',
  styleUrls: ['./business-strategy.component.css']
})
export class BusinessStrategyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
