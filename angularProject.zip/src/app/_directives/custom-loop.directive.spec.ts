import { CustomLoopDirective } from './custom-loop.directive';

describe('CustomLoopDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomLoopDirective();
    expect(directive).toBeTruthy();
  });
});
