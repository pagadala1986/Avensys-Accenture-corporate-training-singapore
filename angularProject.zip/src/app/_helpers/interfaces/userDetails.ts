export interface Users{
  firstname:string,
  lastname:string,
  email:string,
  country:string,
  address:string
}
